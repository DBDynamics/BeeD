from DBDynamics import Bee

m = Bee('/dev/ttyUSB0')
# m = Bee('COM3') # WINDOWS用户
a = m.scanDevices()
print(len(a), a)

m.stop()
