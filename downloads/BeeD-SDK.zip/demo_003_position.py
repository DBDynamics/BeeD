from DBDynamics import Bee

m = Bee('/dev/ttyUSB0')
# m = Bee('COM3') # WINDOWS用户

tp = []
offset = 1000
k = 51200 / 360.0
for axis in range(0, 4):
    tp.append(0)


def mov(p0, p1, p2, p3):
    tp[0] = p0 * k
    tp[1] = p1 * k
    tp[2] = p2 * k
    tp[3] = p3 * k
    for mid in range(0, 4):
        m.setTargetPosition(mid, tp[mid]+offset)
    for mid in range(0, 4):
        m.waitTargetPositionReached(mid)


mov(0, 0, 0, 0)
mov(90, 90, 90, 90)
mov(-90, -90, -90, -90)
mov(90, -90, 90, -90)
mov(-90, 90, -90, 90)
mov(0, 0, 0, 0)
m.stop()
